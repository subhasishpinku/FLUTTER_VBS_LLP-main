package com.example.hookah_user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
