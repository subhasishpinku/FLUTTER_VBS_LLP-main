import 'package:get/get.dart';

class ProductController extends GetxController {}
