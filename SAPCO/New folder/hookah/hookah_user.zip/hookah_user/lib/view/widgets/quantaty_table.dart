import 'package:flutter/material.dart';

class QuantityTable extends StatefulWidget {
  QuantityTable({Key? key}) : super(key: key);

  @override
  State<QuantityTable> createState() => _QuantityTableState();
}

class _QuantityTableState extends State<QuantityTable> {
  int quantity = 1;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.indigo, width: 3),
        borderRadius: BorderRadius.circular(10),
      ),
      margin: const EdgeInsets.all(10),
      width: MediaQuery.of(context).size.width / 3 - 8,
      height: 40,
      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        IconButton(
            onPressed: () {
              setState(() {
                quantity--;
              });
            },
            icon: const Icon(
              Icons.remove,
              color: Colors.indigo,
            )),
        Text(
          ' $quantity',
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        IconButton(
            onPressed: () {
              setState(() {
                quantity++;
              });
            },
            icon: const Icon(Icons.add, color: Colors.indigo))
      ]),
    );
  }
}
