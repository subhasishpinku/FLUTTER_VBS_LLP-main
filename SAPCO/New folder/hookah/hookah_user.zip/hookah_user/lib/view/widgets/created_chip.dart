import 'package:flutter/material.dart';

class CreatedChip extends StatefulWidget {
  const CreatedChip({Key? key}) : super(key: key);

  @override
  State<CreatedChip> createState() => _CreatedChipState();
}

class _CreatedChipState extends State<CreatedChip> {
  bool _isChipSelected = false;
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        ChoiceChip(
            onSelected: (value) {
              setState(() {
                _isChipSelected = value;
              });
            },
            selected: _isChipSelected,
            label: const Text('Lorem Ipsum')),
        SizedBox(width: 5)
      ],
    );
  }
}
