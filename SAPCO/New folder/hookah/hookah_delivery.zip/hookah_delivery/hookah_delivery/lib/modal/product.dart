class Product {
  String id;
  String title;
  String image;
  String description;
  int price;

  Product(
      {required this.id,
      required this.title,
      required this.image,
      required this.description,
      required this.price});
}

class DataList {
  List deliveryList = [
    Product(
      id: DateTime.now().toString(),
      title: 'delivery',
      image: 'image',
      description: 'description',
      price: 10,
    ),
    Product(
        id: DateTime.now().toString(),
        title: 'delivery',
        image: 'image',
        description: 'description',
        price: 10),
    Product(
        id: DateTime.now().toString(),
        title: 'delivery',
        image: 'image',
        description: 'description',
        price: 10),
    Product(
        id: DateTime.now().toString(),
        title: 'delivery',
        image: 'image',
        description: 'description',
        price: 10),
  ];

  List pickupList = [
    Product(
        id: DateTime.now().toString(),
        title: 'pick',
        image: 'image',
        description: 'description',
        price: 10),
    Product(
        id: DateTime.now().toString(),
        title: 'pick',
        image: 'image',
        description: 'description',
        price: 10),
    Product(
        id: DateTime.now().toString(),
        title: 'pick',
        image: 'image',
        description: 'description',
        price: 10),
    Product(
      id: DateTime.now().toString(),
      title: 'pick',
      image: 'image',
      description: 'description',
      price: 10,
    ),
  ];
}
