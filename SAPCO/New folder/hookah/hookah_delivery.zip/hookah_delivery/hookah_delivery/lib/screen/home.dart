import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hookah/modal/product.dart';
import 'package:hookah/widgets/drawerPage.dart';

class Home extends StatefulWidget {
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  var listOfData = DataList().deliveryList;

  final args = Get.arguments;
  getData() {
    if (args == null || args == 'deliveryList') {
      setState(() {
        listOfData = DataList().deliveryList;
      });
    } else {
      setState(() {
        listOfData = DataList().pickupList;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    print(args);
    getData();
    // print(data);
    // print(data1);
    return Scaffold(
      drawer: DrawerPage(),
      appBar:
          // PreferredSize(
          //   preferredSize: Size.fromHeight(70),
          //   child:
          AppBar(
        // shape: RoundedRectangleBorder(
        // borderRadius: BorderRadius.vertical(
        //   bottom: Radius.circular(20),
        // ),
        // ),
        title: Text(args == "deliveryList" ? 'Delivery List' : 'Pickup List'),
      ),
      // ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: DataList().deliveryList.length,
              itemBuilder: (context, index) {
                return Column(
                  children: [
                    ...listOfData.map((item) {
                      // print(item.title);
                      return Card(
                        margin:
                            EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: ListTile(
                            leading: Container(
                              color: Colors.grey,
                              height: 52,
                              width: 52,
                              child: Image.network(
                                'https://images.pexels.com/photos/3794457/pexels-photo-3794457.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
                                fit: BoxFit.cover,
                              ),
                            ),
                            title: Text(item.title),
                            subtitle:
                                Text('${item.description}\n ₹${item.price}'),
                            isThreeLine: true,
                            trailing: ElevatedButton(
                              style: ButtonStyle(
                                padding: MaterialStateProperty.all(
                                    EdgeInsets.only(
                                        right: 30,
                                        left: 30,
                                        top: 4,
                                        bottom: 4)),
                                // minimumSize: MaterialStateProperty.all(),
                                shape: MaterialStateProperty.all(
                                  RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30),
                                  ),
                                ),
                              ),
                              child: Text('view'),
                              onPressed: () {},
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
